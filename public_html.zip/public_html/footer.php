<footer class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col">
                    <h4>Website</h4>
                    <ul>
                        <li><a href="/about/">About Us</a></li>
                        <li><a href="/product/">Our Products</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Keep in touch</h4>
                    <ul>
                        <li><a href="/concern/">Contact Us</a></li>
                        <li><a href="mailto:brewbase@gmail.com">brewbase@gmail.com</a></li>
                        <li><a href="+639123456789">+63 9123-34323-32</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Products</h4>
                    <ul>
                        <li><a href="/product/?search=Milk Tea">Milk Tea</a></li>
                        <li><a href="/product/?search=Frappe">Frappe</a></li>
                        <li><a href="/product/?search=Hot Drinks">Hot Drinks</a></li>
                        <li><a href="/product/?search=Cold Drinks">Cold Drinks</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>follow us</h4>
                    <div class="social-links">
                        <a href="#"><i class="fa fa-facebook-f"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
            <p style="color: white;">&copy; <span style="font-weight: 700;">Brew Base</span> Educational Puposes Only</p>
        </div>
        </div>
    </footer>